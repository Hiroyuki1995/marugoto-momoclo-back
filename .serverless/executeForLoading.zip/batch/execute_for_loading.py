def execute_for_loading(event=None, lambda_context=None):
    print('execute for loading')
