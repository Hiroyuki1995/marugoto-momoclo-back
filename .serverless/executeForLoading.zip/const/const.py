AWS_ACCESS_KEY_ID = "AKIA42AWK5P7QALLIJNF"
AWS_SECRET_ACCESS_KEY = "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"
REGION = "ap-northeast-1"
# instagramアカウント
INSTAGRAM_USER_NAME = "marugotomomoclo"
INSTAGRAM_PASSWORD = "renichankawa"

PHOTOS_TABLE_NAME = "Photos"

USER_BUCKET_NAME = "marugoto-momoclo"
SESSION_BUCKET_NAME = "marugoto-momoclo-secret"
SESSION_FILE_NAME = "session_instagram"

TOPIC_ARNS = {
    "momotakanako": "arn:aws:sns:ap-northeast-1:880515148799:marugoto-momoclo-momotakanako",
    "tamaishiori": "arn:aws:sns:ap-northeast-1:880515148799:marugoto-momoclo-tamaishiori",
    "sasakiayaka": "arn:aws:sns:ap-northeast-1:880515148799:marugoto-momoclo-sasakiayaka",
    "takagireni": "arn:aws:sns:ap-northeast-1:880515148799:marugoto-momoclo-takagireni",
}

PERSON_NAME = {
    "momotakanako": "かなこちゃん❤️",
    "tamaishiori": "しおりん💛",
    "sasakiayaka": "あーりん💗",
    "takagireni": "れにちゃん💜",
}

INSTAGRAM_TARGET_USER_IDS = ["7229150040", "5554498358",
                             "7042508423", "48870961638"]  # 順に高城れに・玉井詩織・百田夏菜子・佐々木彩夏
INSTAGRAM_TARGET_USER_LIST = {
    7042508423: "momotakanako",
    5554498358: "tamaishiori",
    48870961638: "sasakiayaka",
    7229150040: "takagireni",
}
# ↓ユーザーIDの調べ方↓
# https://codeofaninja.com/tools/find-instagram-user-id/

# Twitter ユーザーID
TWITTER_TARGET_ACCOUNT_LIST = [
    {
        "id": 242584825,
        "name": "『ももクロChan』",
        "username": "momoclochan_ex",
    },
    {
        "id": 1233248046420393985,
        "name": "高城れにの週末ももクロ☆パンチ！！",
        "username": "momoclo_punch",
    },
    {
        "id": 3835288154,
        "name": "ももクロインフォ公式",
        "username": "information_mcz",
    },
    {
        "id": 1303235886453198848,
        "name": "『ももクロちゃんと！』【テレビ朝日公式】",
        "username": "momoclochanto",
    },
    {
        "id": 841507450511478784,
        "name": "川上アキラの人のふんどしでひとりふんどし",
        "username": "hitorifundoshi",
    },
    {
        "id": 811420890978086912,
        "name": "ももくろちゃんZ",
        "username": "momoclo_chanz",
    },
    {
        "id": 163404636,
        "name": "momoiroclover",
        "username": "momowgp",
    },
]
TWITTER_AUTHORIZATION_TOKEN = 'Bearer AAAAAAAAAAAAAAAAAAAAAI%2BnYQEAAAAAw4Y3GJ5pnI5qdPtrVGED5hQHF2U%3DzCjGM1KoJOKe8XxBinsLZ6t3gLesNNUFCHIWAdYY6UAtCZ4fxy'  # TODO %のエスケープはしなくてよいか？

BEARER_TOKEN = "AAAAAAAAAAAAAAAAAAAAAI%2BnYQEAAAAAw4Y3GJ5pnI5qdPtrVGED5hQHF2U%3DzCjGM1KoJOKe8XxBinsLZ6t3gLesNNUFCHIWAdYY6UAtCZ4fxy"

GOOGLE_APPLICATION_CREDENTIALS = "./momoclo-edc6d6310591.json"

LINE_MESSAGE_API_KID = "7d7465b0-075e-4c83-9d04-1440341cc7b7"
LINE_MESSAGE_API_PRIVATE_KEY = {
    "alg": "RS256",
    "d": "ZS5uem2uNOFvEVTQfzimQWnRSHKSDHfw3RKlrTyrKB_9MewGgsM0790KGMT936YrKKoKQtOIp2KOkmCFFJZXyBfw5PbSpILTt1iJNrfIljrNBbAGbKPxZ3B6rS_rd1GupRD62cmzHVpG46hI0Mb9Gva1VX4JvhRSXbokedjUFD5wRYlouyoZy-dCxDb1mpZo8fgT4_5hGumb0FNRjt9IpSojwZWcaPV-UpvWaD_sUYYE6XUu8acJxIPDEWqGLeHr-P9kMYcno74Wnc9Vx2O8K1MPemhxBipxjnSvUtYlxJsIaSmOl8tS1jK86ge6otHr2lkJf_P9xG9ZQYisCnFW-w",
    "dp": "LbuzY0fd7K3k1r3QH4uhMpC6_sFv_M5oIA1lA99MPYFseuV6AEi3ccfJNKX9nV64H0Aavh8vQpOEL31JIRes1EAV3KcM0X3_QWZ_YheYNdzoPtTb0bRgulSiOxlLgKBtFht_NZVx7JAaMpaFiQXeYyYNoe6MNrlapQItWpYEe48",
    "dq": "C2QJUSElVSLG1va1kGLwTUj4XzLh_777_LWpZh1Mo9V30IdSEaC30unGeEpgeKImwyuEoD8xb-I1clhPgODDk7zUigmgHOI9U1-vI65TYTSFHJrlx71q1OT-YGYDFSlSDV1N4kDdiQuyUqlieETWOiDEt4T0nyiS-1QIqugQghs",
    "e": "AQAB",
    "kty": "RSA",
    "n": "zXxRgoaijvDaBOjYqi_ClWrj2BicpvDUtMGR2aWfhJagFAAtjqTaIfXy2oWCMlGpAYtmqcFhlBkJOLWYutUCpitMQzi0nKfQtIYmhj3An7N9IE6p9_NzT_ODtDqxbhk38fCZ_AerniJoNuvPeYTrYsiSKHoQ5_GhCP77c0u7Mr0Ckmsny1krUUoiX1e7srhLEj5glEtyG9Mabi9Ra9MNeCeae2r6BoZuf_6gBDp1GvB3Dpvz5q08uxc7s8R7kH-dRMVWoHSJ_yu9m4OTDc0d6nMRzeCnidJ_FYhOgHJqV2_3k_iwJBqM9NEEtj83kE06-JUROeW1owF4PRhYIEhb6Q",
    "p": "9mu-kCjF8Q1wbYCjm_o04BHMAIOldYQiZrOOn4ELUcMhaLXI2cWb0xxUXgXmGSM-Z684Q7qoHzVp057xNiwHk1SMx-K7oNc0ap8CQ7WKYCBJ_07AjceaGmwRwicTordb961wBCOaFqXJH3Bf93v6YXV7cWLnrMTy2l0JjPEEAts",
    "q": "1Xk1A1QAKsKUJi4ofV1jNcC5qWqaEhSf28-Lu61VOJiI5Ox_cnpcEM7VeOyoAfLs1_og7OFNv_4MMVKjVePGpL4P4D2mbwFn_zIJeGJRzzzbaAad4MFzd9MlEhw4KVFGG5_mMwGFl_3nbdw2Sw7lpLZYA6LkjmY0jfJiKhLYHYs",
    "qi": "wiiAkD970YaKiMHMfTCLo2J_X2V3VEVE8g9KrSqt3XzPixFJ3ImMTTR_clBHOnrOxtlzhMCYqN4OTbESxeRZFuUugl6p2nKauEjoSXQ_xZnr1j9IsBybl03A074NFe3VgG0fOyfBuqobA_6RsvvPNvLZYFNrhjgP5FsU---gHWA",
    "use": "sig"
}
LINE_MESSAGE_API_CHANNEL_ID = "1657184240"
LINE_MESSAGE_API_ACCESS_TOKEN = "2kgoJrKb8FS3bg8mS33JkS0KjdU2zf6fD4PhoPscICrY9KbNfZ95gW+HNWSNdJowSxoghVIemnOSOWBr00ovA6u258FE+k+e8UcZPNevV3NZ/GJfg+1gOuG1F8zKvL3kMA1UWIiCYVnMqdcJvGtVBAdB04t89/1O/w1cDnyilFU="
LINE_IWATA_USER_ID = "Ue7a9ac7dd5a0329bfc4d7340378424f3"

GOOGLE_CALENDAR_API_KEY = "AIzaSyBiiMK2fusO4dkKDVAQm7cSYU66vctbD2g"
GOOGLE_CALENDAR_DATA = [
    {
        "id": "resultAnnouncement",
        "category": "LIVE",
        "name": "ライブ結果発表・入金期間",
        "googleCalendarId": "egl79am00drmku06kn4ivfvess@group.calendar.google.com",
    },
    {
        "id": "liveApplicationReception",
        "category": "LIVE",
        "name": "ライブ申込受付期間",
        "googleCalendarId": "momoclo.schedule@gmail.com",
    },
    {
        "id": "liveEvent",
        "category": "LIVE",
        "name": "ライブ公演日",
        "googleCalendarId": "sgjkn6snu9fu8mtl1rnmcqjs3k@group.calendar.google.com",
    },
    {
        "id": "UNREGULARPROGRAM",
        "category": "UNREGULARPROGRAM",
        "name": "番組・配信（不定期）",
        "googleCalendarId": "253i7578skl4b93pkc6r7ubiq0@group.calendar.google.com",
    },
    {
        "id": "REGULARPROGRAM",
        "category": "REGULARPROGRAM",
        "name": "番組・配信（定期）",
        "googleCalendarId": "qpur385sj27sklsl9cg1bp5f98@group.calendar.google.com",
    },
    {
        "id": "others",
        "category": "OTHERS",
        "name": "その他イベント等",
        "googleCalendarId": "l41vh9658f778ormj2n0nvlako@group.calendar.google.com",
    },
]

YOUTUBE_CHANNELS = [
    {
        "id": "UC6YNWTm6zuMFsjqd0PO3G-Q",
        "name": "Momoiro Clover Z Channel"
    }
]
